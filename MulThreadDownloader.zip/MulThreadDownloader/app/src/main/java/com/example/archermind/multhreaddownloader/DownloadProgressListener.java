package com.example.archermind.multhreaddownloader;

public interface DownloadProgressListener {
    public void onDownloadSize(int size);
}