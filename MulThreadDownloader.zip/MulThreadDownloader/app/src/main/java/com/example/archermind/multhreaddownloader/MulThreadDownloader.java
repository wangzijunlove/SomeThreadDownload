package com.example.archermind.multhreaddownloader;

import java.io.File;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MulThreadDownloader extends Activity {
    private EditText pathText;
    private ProgressBar progressBar;
    private TextView resultView;
    @SuppressLint("HandlerLeak")

    /**
     * 当Handler被创建会关联到创建它的当前线程的消息队列，该类用于往消息队列发送消息
     * 消息队列中的消息由当前线程内部进行处理
     */
    private Handler handler = new Handler(){
        public void handleMessage(Message msg) {

            if (!Thread.currentThread().isInterrupted()) {
                switch (msg.what) {
                    case 1:
                        int size = msg.getData().getInt("size");
                        progressBar.setProgress(msg.getData().getInt("size"));
                        int result = (int) (((float) size / (float) progressBar
                                .getMax()) * 100);
                        resultView.setText(+result + "%");
                        if (size == progressBar.getMax()) {
                            Toast.makeText(MulThreadDownloader.this, "文件下载完成",
                                    Toast.LENGTH_LONG).show();
                        }
                        break;
                    case -1:
                        String error = msg.getData().getString("error");
                        Toast.makeText(MulThreadDownloader.this, error,
                                Toast.LENGTH_LONG).show();
                        break;
                }
            }
            super.handleMessage(msg);
        }
    };
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        pathText = (EditText)findViewById(R.id.path);
        progressBar = (ProgressBar)findViewById(R.id.downloadbar);
        resultView = (TextView)findViewById(R.id.resultView);
        Button button = (Button)findViewById(R.id.button);
        button.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String path = pathText.getText().toString().trim();
                //Environment.MEDIA_MOUNTED 判断SD卡是否存在
                //Environment.getExternalStorageDirectory()获取根目录
                if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){
                    download(path,Environment.getExternalStorageDirectory());
                }
                else{
                    Toast.makeText(MulThreadDownloader.this, R.string.sdcarderror, Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    /**
     * 主线程(UI线程)
     * 对于显示控件的界面更新只是由UI线程负责，如果是在非UI线程更新控件的属性值，更新后的显示界面不会反映到屏幕上
     * @param path
     * @param saveDir
     */
    private void download(final String path,final File saveDir) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                FileDownloader downer = new FileDownloader(MulThreadDownloader.this,path,saveDir,3);
                progressBar.setMax(downer.getFileSize());//设置进度条最大刻度为文件的长度
                try{
                    downer.download(new DownloadProgressListener(){
                        public void onDownloadSize(int size){ //实时获取文件已经下载的数据长度
                            Message msg = new Message();
                            msg.what = 1;
                            msg.getData().putInt("size", size);
                            handler.sendMessage(msg);
                        }
                    });
                }catch(Exception e){
                    Message msg = new Message();
                    msg.what = -1;
                    msg.getData().putString("error", "下载失败");
                    handler.sendMessage(msg);
                }
            }
        }).start();
    }
}